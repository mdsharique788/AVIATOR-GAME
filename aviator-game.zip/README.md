
# Aviator — Free Play (HTML/CSS/JS)

A simple **Aviator-style** multiplier game for fun and learning. Uses virtual coins (no real money).

## How to run locally
1. Extract the ZIP and open `index.html` in your browser.
2. Place a bet using the Bet input and click **Place Bet**.
3. Click **Cash Out** before the plane crashes to win virtual coins.

## How to publish on GitHub Pages (step-by-step)
1. Create a free GitHub account at https://github.com/
2. Create a new **public** repository (e.g., `aviator-free`).
3. Click **Add file → Upload files**, then drag-and-drop the files from this ZIP (`index.html`, `style.css`, `script.js`, `README.md`).
4. Commit the changes.
5. Go to the repository **Settings → Pages** (left sidebar) and set the source to branch `main` and folder `/ (root)` then Save.
6. After a minute or two, your site will be live at: `https://<your-username>.github.io/<repo-name>/`

> **Screenshot guidance**: In the GitHub UI you'll see buttons **"Add file"** in the repo main view and **"Settings"** in the top menu — those are what you should click.

## Notes and customization ideas
- Improve visuals (plane sprite, progress bar).
- Add sound effects.
- Save leaderboard using `localStorage` or Firebase.
- This is for educational/demo only — do not use real money.

---
Made for you — feel free to modify.

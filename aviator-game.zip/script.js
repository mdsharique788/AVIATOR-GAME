
// Simple Aviator-style free-play game (no money).
// Mechanics: place bet (virtual coins), start round, multiplier increases, random crash occurs.
// Click Cash Out before crash to win bet * multiplier. Otherwise lose bet.
// This is educational/sample code and intentionally simple.

const balanceEl = document.getElementById('balance');
const betEl = document.getElementById('bet');
const placeBtn = document.getElementById('placeBet');
const cashoutBtn = document.getElementById('cashout');
const multiplierEl = document.getElementById('multiplier');
const planeEl = document.getElementById('plane');
const statusEl = document.getElementById('status');
const historyList = document.getElementById('historyList');

let balance = 1000;
let currentBet = 0;
let roundRunning = false;
let multiplier = 1.0;
let crashAt = 0;
let animationFrame = null;

function updateBalance(){
  balanceEl.textContent = balance.toFixed(0);
}

function randCrash(){
  // Generate a random crash in a simple bias: more likely to be small
  // Use an exponential distribution to simulate variety.
  const r = Math.random();
  // scale to range [1.05, 12.00]
  const val = Math.max(1.05, Math.exp(r*2.2));
  return Math.min(val, 50);
}

function startRound(){
  if (roundRunning) return;
  currentBet = parseFloat(betEl.value) || 0;
  if (currentBet <=0 || currentBet > balance){
    alert('Invalid bet. Make sure it is >0 and ≤ your balance.');
    return;
  }
  balance -= currentBet;
  updateBalance();
  placeBtn.disabled = true;
  betEl.disabled = true;
  cashoutBtn.disabled = false;
  statusEl.textContent = 'Round running...';
  multiplier = 1.0;
  multiplierEl.textContent = multiplier.toFixed(2) + 'x';
  planeEl.style.left = '20px';
  planeEl.style.bottom = '12px';
  crashAt = randCrash();
  roundRunning = true;
  runMultiplier();
}

function runMultiplier(){
  const start = performance.now();
  function step(now){
    const elapsed = (now - start)/1000; // seconds
    // acceleration curve for multiplier
    multiplier = 1 + Math.pow(elapsed, 1.6) * 0.7;
    multiplierEl.textContent = multiplier.toFixed(2) + 'x';
    // move plane visually by multiplier (clamped)
    const pct = Math.min((multiplier-1)/ (crashAt-1), 1);
    planeEl.style.left = (20 + pct* (window.innerWidth*0.4)) + 'px';
    planeEl.style.transform = 'scale(' + (1 + multiplier/40) + ') rotate(' + (multiplier*3) + 'deg)';
    if (multiplier >= crashAt){
      // crash!
      endRound(false);
      return;
    }
    animationFrame = requestAnimationFrame(step);
  }
  animationFrame = requestAnimationFrame(step);
}

function cashOut(){
  if (!roundRunning) return;
  // player cashes out at current multiplier
  const win = currentBet * multiplier;
  balance += Math.floor(win);
  addHistory(true, multiplier, Math.floor(win));
  endRound(true);
}

function endRound(won){
  roundRunning = false;
  placeBtn.disabled = false;
  betEl.disabled = false;
  cashoutBtn.disabled = true;
  if (animationFrame) cancelAnimationFrame(animationFrame);
  if (won){
    statusEl.textContent = 'You cashed out!';
    alert('You cashed out at ' + multiplier.toFixed(2) + 'x and won ' + Math.floor(currentBet*multiplier) + ' coins!');
  } else {
    statusEl.textContent = 'Crashed at ' + crashAt.toFixed(2) + 'x — You lost the bet.';
    // reveal crash visually
    multiplierEl.textContent = crashAt.toFixed(2) + 'x (CRASH)';
    planeEl.style.transform = 'translateY(-40px) rotate(160deg) scale(0.9)';
    addHistory(false, crashAt, 0);
  }
  updateBalance();
  currentBet = 0;
}

function addHistory(won, mult, amount){
  const li = document.createElement('li');
  if (won){
    li.textContent = 'Win: cashed out at ' + mult.toFixed(2) + 'x — +' + amount + ' coins';
    li.style.color = '#10b981';
  } else {
    li.textContent = 'Loss: crashed at ' + mult.toFixed(2) + 'x';
    li.style.color = '#ef4444';
  }
  historyList.prepend(li);
  // keep only last 20
  while(historyList.children.length>20) historyList.removeChild(historyList.lastChild);
}

placeBtn.addEventListener('click', startRound);
cashoutBtn.addEventListener('click', cashOut);
updateBalance();
